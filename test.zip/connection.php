<?php 
$host = 'localhost'; // адрес сервера 
$database = 'test'; // имя базы данных
$user = 'root'; // имя пользователя
$password = ''; // пароль
 ?>